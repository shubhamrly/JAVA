package Emp;

public class EmpMang {
int empId;
String empName;
String email;
String gender; 
float salary;
 void GetEmployeeDetails() 
 {
	System.out.println(empId + empName+ email+gender+salary); 
 }
}
